package service;
import java.util.Map;

import bean.Customer;
import dao.DaoClass;
public class ServClass {
	
	DaoClass daobj = new DaoClass();
	
	
	public void servStore(Customer obj) {
		daobj.storeDeatails(obj);
	}
public Map<Integer,Object> serhDetails() {
	
	Map<Integer,Object> sermObj = daobj.showTabledata();
	return sermObj;
}
}

package bean;

public class Customer {
 String cName;
 long mNum;
 int table;
 static int tables= 1;
 static int tableCount =1;
 public Customer(String cName, long mNum,int table) {
	super();
	this.cName = cName;
	this.mNum = mNum;
	this.table = tablesCount();
}
 public int getCount() {
	 return tableCount++;
	 
 }
 public int tablesCount() {
	 return tables++;
	 
 }

public String getcName() {
	return cName;
}

public void setcName(String cName) {
	this.cName = cName;
}

public long getmNum() {
	return mNum;
}

public void setmNum(long mNum) {
	this.mNum = mNum;
}

public int getTable() {
	return table;
}

public void setTable(int table) {
	this.table = table;
}



@Override
public String toString() {
	return "Customer [cName=" + cName + ", mNum=" + mNum + ", table=" + table + "]";
}

}


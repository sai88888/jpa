package dao;

import service.ServClass;

import java.util.HashMap;

import bean.Customer;

public class DaoClass {
	
	public static int MAX = 2;
	HashMap<Integer,Object> hm = new HashMap<Integer,Object>();
public void storeDeatails(Customer obj) {
	int table = obj.getCount();
	
	if(MAX > 0) {
	hm.put(table,obj);
	MAX--;
	}
	else
	{
		System.out.println("tables are not available");
		System.exit(0);
	}
}
public  HashMap<Integer,Object> showTabledata (){
	return (HashMap<Integer,Object>) hm;
	
}
}

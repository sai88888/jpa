package ui;

import bean.Customer;
import dao.DaoClass;
import service.ServClass;

import java.util.Map;
import java.util.Scanner;

public class MainClass {
	
	int tab=1;
	Scanner sc = new Scanner(System.in);
	ServClass serobj =new ServClass();
	public void bookTable() {
	
	System.out.println("enter customer");
	String cName = sc.next();
	System.out.println("enter customer mobile");
	 long mNum= sc.nextLong();
	 Customer cusobj = new Customer(cName, mNum, tab);
	 System.out.println(cusobj);
	 
	 serobj.servStore(cusobj);
	 System.out.println("no of tables availble"+ (DaoClass.MAX+1));
	}
	
	
	public void showTable() {
	System.out.println("enter table number");
	int tbl = sc.nextInt();
	
	Map<Integer,Object> mainObj = serobj.serhDetails();
	System.out.println(mainObj.get(tbl));
		
	}
	
	public int addTables() {
		System.out.println("how many tables you want to add");
		int add = sc.nextInt();
		DaoClass.MAX = DaoClass.MAX+add;
		System.out.println(DaoClass.MAX);
		return DaoClass.MAX;
	}
	
}

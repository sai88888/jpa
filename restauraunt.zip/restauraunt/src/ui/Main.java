package ui;

import java.util.Scanner;
public class Main {
public static void main(String args[]) {
	int choice;
	char option;
	MainClass almObj=new MainClass();
	Scanner sc = new Scanner(System.in);
	do {
	System.out.println("Welcome to XYZ\n"+"1. to book table\n"+"2. to show table\n"+"3. to add new table \n"+"4. exit");
	
	System.out.println("Enter Your Choice");
	choice = sc.nextInt();
	switch (choice)
	{
	case 1:
	{
		almObj.bookTable();
		break;
	}
	case 2:
	{
		almObj.showTable();
		break;
	}
	case 3:
	{	
		almObj.addTables();
		break;
	}
	case 4:
	{	
		System.out.println("thank you visit again");
		System.exit(0);
		break;
	}
	
	}
	System.out.println("DO YOU WISH TO CONTINUE:enter :: Y/N");
	option=sc.next().charAt(0);
	if(option=='Y')
	{
		continue;
	}
	else 
	{
		System.out.println("THANK YOU--visit again");
		System.exit(0);
	}
	}while(choice>=1||choice<=4);
	sc.close();
}
}

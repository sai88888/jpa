package com.cg.jpa.service;
import com.cg.jpa.entities.*;


public interface AuthorService {

	public abstract void addAuthor(Author author);

	public abstract void updateAuthor(Author author);

	public abstract void removeAuthor(Author author);

	public abstract Author findAuthorById(int id);
	
}
